export default function Home() {
  return (
    <>
      <h2>Home componenet...</h2>
    </>
  );
}
