export default function Contact() {
  return (
    <>
      <h2>Contact component...</h2>
    </>
  );
}
